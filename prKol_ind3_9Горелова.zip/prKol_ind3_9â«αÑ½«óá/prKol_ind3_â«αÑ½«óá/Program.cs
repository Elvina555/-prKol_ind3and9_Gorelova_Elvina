﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using static System.IO.File;
using System.Threading.Tasks;

namespace prKol_ind3_Горелова
{
    class Program
    {
        static void Main(string[] args)
        { //3
            string[] l = File.ReadAllLines("file.txt");
            foreach (string line in l)
            {
                char[] a = line.ToCharArray();
                Array.Reverse(a);
                Console.WriteLine(a);
            }
            Stack<string> l2 = new Stack<string>(l);
            foreach (string lines in l2)
            {
                AppendAllText("file1.txt", (lines) + "\n");
            }
            Console.ReadKey();
            //9
            Stack<int> file = new Stack<int>();
            Console.WriteLine("Введите название файла(f1): ");
            string nazv = Console.ReadLine();
            if (File.Exists(nazv + ".txt"))
            {
                if (new FileInfo(nazv + ".txt").Length == 0)
                {
                    Console.WriteLine("Файл пуст");
                }
                else
                {
                    string[] c = File.ReadAllLines(nazv + ".txt");
                    for (int j = 0; j < c.Length; j++)
                    {
                        Console.WriteLine($"Числа:{c[j]}");
                        for (int i = 0; i < c[j].Length; i++)
                        {
                            Random rnd= new Random();
                            char c1 = c[j][i];
                            int n = Convert.ToInt32(c[j][0].ToString());
                            if (char.IsDigit(c1))
                            {
                                file.Push(Convert.ToInt32(c1.ToString()));
                            }
                            else if (c1 == 'm')
                            {
                                int a = rnd.Next(0, n);
                                int b = rnd.Next(0, n);
                                int rez = (a - b) % 10;
                                file.Push(rez);
                            }
                            else if (c1 == 'p')
                            {
                                int a = rnd.Next(0, n);
                                int b = rnd.Next(0, n);
                                int rez = (a + b) % 10;
                                file.Push(rez);
                            }
                        }
                        Console.WriteLine($"Результат: {file.Pop()}");
                    }
                }
            }
            else
            {
                Console.WriteLine("Файл не найден");
            }
            Console.ReadKey();
        }
        
    }
}
